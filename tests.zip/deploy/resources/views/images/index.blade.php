<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Uploader Test</title>
    <!-- Vite manifest file -->
    @vite('resources/js/app.js')
</head>
<body>
    <div >
        <image-uploader></image-uploader>
    </div>
    
    <!-- Vite JS file -->
    @vite('resources/js/app.js')
</body>
</html>
